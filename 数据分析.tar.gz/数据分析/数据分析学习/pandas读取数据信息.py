import  pandas as pd
import  numpy as np
#pandas读取excel方法
t1=pd.read_excel("../实训耗材数据/库存信息_20191224202755.xls")
print(t1)
#pd.read_sql(sql_sentence.connection)#读取数据库信息



