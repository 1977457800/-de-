from matplotlib import pyplot as plt
from matplotlib import  font_manager
my_font =font_manager.FontProperties(fname="/usr/share/fonts/truetype/wqy/wqy-microhei.ttc")
a=['爱情','好歌']
b=[56,81]
c=[22,44]
d=[10,60]
fig, ax = plt.subplots()
e = ax.bar(range(len(a)),b,color='#6699CC')
# 添加数据标签
for rect in e:
    w = rect.get_height()
    ax.text(w, rect.y() + rect.get_height() / 2, '%d' % int(w), ha='left', va='center')

# 设置Y轴刻度线标签6699CC
ax.set_yticks(range(len(a)))
ax.set_yticklabels(a, FontProperties=my_font, size=8, color='black')
plt.show()