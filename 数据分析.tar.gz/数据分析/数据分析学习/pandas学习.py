import  pandas as pd
import  numpy as np
#pandas读取excel方法
excls=pd.read_excel("./条形图.py")
#pd.read_sql(sql_sentence.connection)#读取数据库信息


