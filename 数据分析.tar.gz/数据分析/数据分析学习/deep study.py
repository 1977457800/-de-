import cv2
import numpy
import matplotlib.pyplot as plt

#导入图片
from 数据分析.数据分析学习.CarDetect import sess, ret, x

j=1
i=0
p=0
arr=["10","20","30","40","50","60","70","80"]
while(i<7):
    pic = cv2.imread("datas/CarData/TestImages/test-"+arr[i]+".pgm", 0)
    size = pic.shape
    
    img  = numpy.reshape(pic, (-1, size[0], size[1], 1))
    #利用上面训练好的网络，开始在新的图片中检测
    result = sess.run(ret, feed_dict={x:img})
    
    #将检测结果显示
    pt1 = numpy.array([result.argmax() // result.shape[2], result.argmax() % result.shape[2]]) * 4
    pt2 = pt1 + numpy.array([40, 100])
    
    pic_2 = cv2.rectangle(pic, (pt1[1], pt1[0]), (pt2[1], pt2[0]), 0, 2)
    
    plt.imshow(pic_2, "gray")
    plt.show()
    i=i+1
