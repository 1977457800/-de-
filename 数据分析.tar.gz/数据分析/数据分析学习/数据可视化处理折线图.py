from matplotlib import pyplot as plt
import random
y1=[random.randint(20,35) for i in range(120)]
y2=[random.randint(30,35) for i in range(120)]#产生120个随机数
x=range(0,120)   #120个数字
plt.plot(x,y1,label='first')#画图
plt.plot(x,y2,label='second')#将y1和y2画在一起
_xtick_lables = ["h1{}".format(i) for i in range(60)]
_xtick_lables+=["h2{}".format(i) for i in range(60)]#x轴坐标系连接字符串
plt.xlabel('X')
plt.ylabel('Y')
plt.title('title')
plt.grid()#画网格
plt.xticks(list(x)[::10],_xtick_lables[::10],rotation=45)    #要求图片以15单位距离输出且使用字符串格式   #严格要求x轴按照上述显示  #rotation旋转角度
plt.savefig("./t1.png")#保存当前文件夹下
plt.legend()
plt.show()