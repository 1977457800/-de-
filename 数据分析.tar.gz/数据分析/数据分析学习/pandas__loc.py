import  pandas as pd
import  numpy as np
t1 =pd.DataFrame(np.arange(20).reshape(4,5),index=list("abcd"),columns=list("WYZGQ"))
print(t1)
t1.loc[["a",'c']]#输出a行和c行
t1.loc[['a','c'],['W','Z']]#输出A行，C行,W和Z列

