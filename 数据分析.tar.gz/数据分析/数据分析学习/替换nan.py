import numpy as np


t1=np.arange(20).reshape(4,5).astype(float)
t1[0:2,2:4]=np.nan
print(t1)
t2=np.count_nonzero(np.isnan(t1))#统计nan个数
print(t2) 