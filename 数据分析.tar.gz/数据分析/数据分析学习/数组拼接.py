import  numpy as np
t1=np.arange(24).reshape(2,12)
t2=np.arange(24).reshape(2,12)
t3=np.vstack((t1,t2))#两个数组庶直拼结
t4=np.hstack((t1,t2))#两个数组水平拼接
t4[[0,1],:]=t4[[1,0],:]#行交换
t4[:,[0,1]]==t4[:,[1,0]]#列交换
t5=np.argmax(t1,axis=1)
print(t1)
print(t5)