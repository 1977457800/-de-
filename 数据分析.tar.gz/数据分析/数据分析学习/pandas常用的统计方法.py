import pandas as pd
pd.read_excel('/home/liuhao/CarDetect/数据分析/实训耗材数据/数据分析excel表/库存信息_20191224202755.xls')
for i in set(all['物品类别']):
    print(i)