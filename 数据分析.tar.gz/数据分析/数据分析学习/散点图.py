from matplotlib import pyplot as plt
from matplotlib import font_manager
import seaborn as sns
my_font =font_manager.FontProperties(fname="/System/Library/Fonts/Hiragino Sans GB.ttc")

y_1= [11,12,17,16,15,14]
y_2= [20,21,24,26,25,19]

x_1=range(1,7)

sns.lmplot(x='hhhhhh',y='jjjjj',data=y_2,ci=None)
plt.scatter(x_1,y_1)

plt.show()