#温度信息：2~24之间的温度
import  random
from matplotlib import  pyplot as plt
from matplotlib import  font_manager
my_font =font_manager.FontProperties(fname="/usr/share/fonts/truetype/wqy/wqy-microhei.ttc")


a=[1,0,1,1,2,4,3,2,3,4,4,5,6,5,4,3,3,1,1,1]
b=list(range(11,31))
plt.xticks(b)
plt.yticks(a)
plt.plot(b,a,linestyle='--')#linestyle：线条
plt.xlabel('年纪',FontProperties=my_font)
plt.ylabel('谈朋友的数量',FontProperties=my_font)
plt.show()


