import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from matplotlib import  font_manager
my_font =font_manager.FontProperties(fname="/usr/share/fonts/truetype/wqy/wqy-microhei.ttc")
import  numpy as np
#t1:库存信息exel表格
All=pd.read_excel("/home/liuhao/CarDetect/数据分析/实训耗材数据/数据分析excel表/库存信息_20191224202755.xls")
store_number_sum=All[['库存数量']].groupby(by=[All['物品类别'],All['物品名称']]).sum()#统计相同类别相同名称的库存数量
