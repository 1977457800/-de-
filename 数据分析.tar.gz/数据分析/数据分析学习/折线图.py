import matplotlib.pyplot as plt
import numpy as np


a=np.array([0.15,0.16,0.14,0.17,0.12,0.16,0.1,0.08,0.05,0.07,0.06]);
max_indx=np.argmax(a)#max value index
min_indx=np.argmin(a)#min value index
plt.plot(a,'r-o')
plt.plot(max_indx,a[max_indx],'gs')
show_max='['+str(max_indx)+' '+str(a[max_indx])+']'
plt.annotate(show_max,xytext=(max_indx,a[max_indx]),xy=(max_indx,a[max_indx]))
plt.plot(min_indx,a[min_indx],'gs')
plt.show()






#
#
#
#
# store_number_sum=All[['库存数量']].groupby(by=[All['物品类别'],All['物品名称']]).sum()#统计相同类别相同名称的库存数量
#
#
# n=0
# for item_kind_name in item_kind:#array(['教学使用类', '办公用品类', '其它类', '工具类', '其他类', '低值仪器仪表', '劳保类', '材料类耗材'],
#     locals()['a'+str(n)]=store_number_sum.loc[item_kind_name]
#     print('a'+str(n))
#     n=n+1#a0,a1,a2,a3,a4,a5,a6,a7
#
# plt.figure(figsize=(28, 88), dpi=200)  # 图片大小，线宽
# for m in range(len(item_kind)):
#     plt.plot(range(len(locals()['a'+str(m)])),locals()['a'+str(m)].values.reshape(len(locals()['a'+str(m)].values)),label=item_kind_name)#教学使用类不同物品的仓库存量总和,label='first')
# plt.title('仓库容量',FontProperties=my_font)
# for item_kind_name in item_kind:
#     xtick_lables = ["{}".format(i) for i in store_number_sum.loc[item_kind_name].index]
#     plt.xticks(xtick_lables[::10],rotation=90)
# plt.grid()#画网格
# plt.show()
