import numpy as np
import matplotlib.pyplot as plt

fig = plt.figure(figsize=(60, 60))
ax = fig.add_subplot(111)

ax.spines['top'].set_color('none')
ax.spines['right'].set_color('none')




ax.xaxis.set_ticks_position('bottom')
ax.spines['bottom'].set_position(('data', 50))
ax.yaxis.set_ticks_position('left')
ax.spines['left'].set_position(('data', 50))






theta = np.arange(0, 2*np.pi, 2*np.pi/100)
ax.plot(np.cos(theta), np.sin(theta))

plt.style.use('ggplot')
ax.set_xticks([-1.2, 1.2])
ax.set_yticks([-1.2, 1.2])

plt.show()