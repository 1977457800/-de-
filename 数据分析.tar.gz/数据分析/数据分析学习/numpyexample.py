import numpy as np
import random
#===========================================一维数组创建=========================================
np.random.seed(1)
t2=np.array([random.random()for i in range(20)]).reshape(4,5)#制造10个随机小数数组
print(t2)

print(np.sum(t2,axis=0))#求每一列的和
print(np.mean(t2))#求平均值
print(np.median(t2))#求中值
print(np.max(t2))#求最大值
print(np.min(t2))#求最小值
print(np.ptp(t2))#求极值
print(np.std(t2))#求标准差














