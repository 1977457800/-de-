from matplotlib import pyplot as plt
from matplotlib import  font_manager

edu=[0.2,0.1,0.2,0.4,0.1]
label=['中专','大专','大学生','武帝','孟婆']
#
my_font =font_manager.FontProperties(fname="/usr/share/fonts/truetype/wqy/wqy-microhei.ttc")
plt.rcParams['font.family']=['AR PL UKai CN']

plt.pie(x=edu,labels=label,autopct='%.1f%%')
plt.show()