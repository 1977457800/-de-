data=list(range(10))
