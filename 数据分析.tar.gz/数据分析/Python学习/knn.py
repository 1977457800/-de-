import numpy as np  #导入numpy，用于科学计算，如，矩阵运算
import matplotlib.pyplot as plt #导入图像显示库pyplot，如折线图
import random #导入随机函数库，生成随机数
##### 10个样本数据
data_X = [
    [-0.32236679, -1.38462662],#标签值：0
    [-0.60582652, -1.93436036],#标签值：0
    [-2.37209117, -0.34753905],#标签值：0
    [-0.13360596,  0.96327911],#标签值：0
    [-1.43553756, -0.84890974],#标签值：0
    [ 3.70753694,  0.98062288],#标签值：1
    [ 2.029152  , -0.1819102 ],#标签值：1
    [ 5.45626862, -1.20479895],#标签值：1
    [ 4.07688348, -0.29181106],#标签值：1
    [ 4.22392082, -2.92426277] #标签值：1
]
data_y = [0, 0, 0, 0, 0, 1, 1, 1, 1, 1] #标签数据，0代表良性肿瘤，1代表恶性肿瘤，是个二分类问题
data_y_name = ['良性肿瘤','恶性肿瘤']#分类名称，0：良性肿瘤，1：恶性肿瘤

X_train = np.array(data_X)  #转为numpy ndarray格式
y_train = np.array(data_y)  #转为numpy ndarray格式

x1 = X_train[y_train == 0,0] #在下标为0的列上，标签值为0的所有值，作为x1
y1 = X_train[y_train == 0,1] #在下标为0的列上，标签值为0的所有值，作为y1
plt.scatter(x1,y1,label="良性肿瘤") #把样本数据x1，y1显示在图像上

x2 = X_train[y_train == 1,0] #在下标为0的列上，标签值为1的所有值，作为x2
y2 = X_train[y_train == 1,1] #在下标为1的列上，标签值为1的所有值，作为y2
plt.scatter(x2,y2,label="恶性肿瘤") #把样本数据x2，y2显示在图像上

x = np.array([5, -0.565731514])  #把需要预测的x显示在图像上
plt.scatter(x[0],x[1],label="预测点")

plt.show() #显示图像，效果如下















from sklearn.neighbors import KNeighborsClassifier   # 包装好的knn算法
kNN_classifier = KNeighborsClassifier(n_neighbors=6)     # knn中k取6
kNN_classifier.fit(X_train, y_train)  # fit 拟合    放入数据和标签       返回值是机器学习类本身
X_predict = x.reshape(1, -1)   # 这样就改为了矩阵
kNN_classifier.predict(X_predict)
y_predict = kNN_classifier.predict(X_predict)
y_predict[0]
print(data_y_name[y_predict[0]])