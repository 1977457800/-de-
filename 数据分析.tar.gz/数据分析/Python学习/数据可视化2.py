from matplotlib import  pyplot as plt
from matplotlib import  font_manager
my_font =font_manager.FontProperties(fname="/usr/share/fonts/truetype/wqy/wqy-microhei.ttc")
#
# x1=['10点{}分'.format(i) for i in range(60)]
# x1+=['11点{}分'.format(i)  for i in range(60)]
# plt.legend()#添加图例，alpha:线性透明度
