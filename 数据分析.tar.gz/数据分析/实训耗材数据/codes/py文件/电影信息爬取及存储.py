import requests
import pymysql
import xlwt
import numpy as np
from bs4 import BeautifulSoup
url='http://58921.com/alltime/2019'
response=requests.get(url)
All=[]
year=[]
day=[]
name=[]
time=[]
data=response.content.decode('utf-8')
html=BeautifulSoup(data,'html.parser')
movie_data=html.find_all('tr')
for i in movie_data:
    one=i.text.split()
    All.append(np.array(one))
All=np.array(All)

filename=['年度排名','历史排名','电影名称','上映年份']

for i in range(1,len(All)):
    year.append(All[i][0][0])
    time.append(All[i][0][-8:-4])
    if All[i][0][1] !='0':
        day.append(All[i][0][1:3])
        name.append(All[i][0][3:9])
    else:
        day.append(All[i][0][1])
        name.append(All[i][0][2:9])

#===========================写入xecel表格=========================================
wb=xlwt.Workbook()
sheet=wb.add_sheet('2019年票房数据')
for i in range(4):
    sheet.write(0,i,filename[i])

def ex(what,where):
    for j in range(1,len(year)):
        sheet.write(j,where,what[j-1])

ex(year,0)
ex(name,2)
ex(day,1)
ex(time,3)
wb.save('./hg.xls')
#===========================写入mysql====================================
db = pymysql.connect(host="127.0.0.1", port=3306,user="this", password="123456", database="haoge",charset="utf8")
cursor=db.cursor()
sql='show tables'
cursor.execute(sql)
for i in cursor.fetchall():
    if i[0] =='movie':
        break
else:
    sql="create table movie (YEAR varchar(10),DAY varchar(20),NAME char(20),TIME varchar(10))"
    cursor.execute(sql)


sql="insert into `movie` (YEAR,DAY,NAME ,TIME )   values (%s,%s,%s,%s)"
print('88888')
for i in range(20):
    cursor.execute(sql,(year[i],day[i],name[i],time[i]))
db.commit()

cursor.close()



