import pymysql
import pandas as pd
# 打开数据库连接
db = pymysql.connect("127.0.0.1", "this", "123456", "haoge")
All=pd.read_excel('/home/haoge/桌面/500GB/备份/文档/数据分析/实训耗材数据/数据分析excel表/库存信息_20191224202755.xls')
# 使用 cursor() 方法创建一个游标对象 cursor




def create():
    cursor = db.cursor()
    # 使用 execute() 方法执行 SQL，如果表存在则删除
    cursor.execute("DROP TABLE IF EXISTS ONE")
    # 使用预处理语句创建表
    one = """CREATE TABLE ONE (
             物品类别  CHAR(20) NOT NULL,
             物品名称  CHAR(20),
             库存数量 INT,  
             进货单价 INT,
             进货金额 INT,
              仓库    CHAR (20))
              """
    cursor.execute(one)#数据库的创
    cursor.close()
    return one

def insert(one):
    cursor = db.cursor()
    sql = "INSERT INTO `ONE`(物品类别, \
           物品名称, 库存数量, 进货单价, 进货金额,仓库) \
           VALUES (%s,%s,%s,%s,%s)"

    var=(('10','20',3,5,7,'安徽'),('11','60',9,5,5,'ppp'))
    cursor.executemany(sql,var)

#===================插入数据
# 
# var=(('pp','ss',3,5,8,'ss'),('pp','ss',3,5,8,'ss'))
# cursor.executemany(sql,var)
# 
insert()



















# 关闭数据库连接
db.close()